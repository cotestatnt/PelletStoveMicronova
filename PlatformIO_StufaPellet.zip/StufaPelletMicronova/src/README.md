# PelletStoveMicronova
Half Duplex serial communication with ESP8266 and Micronova Stove controller

For more reference about Micronova controller
https://k3a.me/ir-controller-for-pellet-stove-with-micronova-controller-stufe-e-pellet-aria-ir-telecomando/
